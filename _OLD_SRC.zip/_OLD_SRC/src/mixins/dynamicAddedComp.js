

GV.dynamicAddedComp = {
    created: function() {
        var container = document.getElementById("gv-container");
        var div = document.createElement('div');
        div.id = this.divId;
        container.appendChild(div);
        this.$mount("#" + this.divId);
    }
};
