
GV.init = function (options) {
    "use strict";

    // imposto configurazione applicazione
    GV.config.set(options);

    // imposto metodo per drag panelli
    GV.util.setDrag();

    new Vue({
        el: '#gv-container',
        template: '<gv-app></gv-app>'
    });
};


