/**
 * Created by parodi on 19/09/2016.
 */
GV.Buttons.locate = function(btnOptions, map) {
    "use strict";

    return new L.Control.Locate(btnOptions);
};