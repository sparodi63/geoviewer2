/**
 * Created by parodi on 19/09/2016.
 */
GV.Buttons.fullscreen = function(btnOptions, map) {
    "use strict";

    return L.control.fullscreen(btnOptions);
};