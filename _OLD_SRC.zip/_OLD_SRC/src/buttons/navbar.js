import GV from '../GV'
import util from '../util'
var L = require('leaflet')

GV.Buttons.navbar = function (btnOptions, map) {
  'use strict'

  if (util.isTouch()) {
    return null
  }
  return L.control.navbar(btnOptions)
}