/**
 * Created by parodi on 19/09/2016.
 */
GV.Buttons.geocoder = function(btnOptions, map) {
    "use strict";

    return new L.Control.Geocoder(btnOptions);
};