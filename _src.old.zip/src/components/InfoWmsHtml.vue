<template>
        <div class="info-wms-html" id="gv-info-wms-html">
            <gv-title v-draggable :title="title" :divId="'gv-info-wms-html'"></gv-title>
            <gv-iframe-panel :html="html" :height="height" :width="width" ></gv-iframe-panel>
        </div>
</template>


<script>
import Vue from 'vue'


export default {
  name: 'gv-info-wms-html',
  props: ['title', 'html', 'width', 'height'],
}
</script>

<style scoped>
.info-wms-html {
  position: absolute;
  left: 0;
  top: 0;
  margin-left: 10px;
  margin-top: 80px;
  background-color: #fff;
  z-index: 800;
}
</style>