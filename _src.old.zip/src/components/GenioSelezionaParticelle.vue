<template>
  <div id="gv-genio-seleziona-particelle-panel" class="gv-genio-seleziona-particelle-panel">
    <gv-title
      title="Seleziona Particelle"
      :divId="'gv-genio-seleziona-particelle-panel'"
      :noClose="true"
      v-draggable
    ></gv-title>
    <div class="gv-genio-seleziona-particelle-body gv-inverted-color-scheme">
      <div class="gv-genio-seleziona-particelle-table">
        <el-table
          :data="particelleSelezionate"
          empty-text="Nessuna particella selezionata"
          @cell-mouse-enter="selectRiga"
          @cell-mouse-leave="deselectRiga"
          highlight-current-row
          style="max-height: 300px"
          :cell-style="{padding: '2px', maxHeight: '10px'}"
        >
          <el-table-column label="ESTREMI" align="center" width="150">
            <template slot-scope="scope">
              <el-popover trigger="hover" placement="bottom">
                <p>COMUNE: {{ scope.row.properties.CT24_COD_COM }}</p>
              </el-popover>
              <div slot="reference" class="name-wrapper">{{ scope.row.label }}</div>
              <!-- <span>{{scope.row.label}}</span> -->
            </template>
          </el-table-column>
          <el-table-column label="PROT" align="center" width="60">
            <template slot-scope="scope">
              <span>{{scope.row.properties.CT24_PROT_IN}}</span>
            </template>
          </el-table-column>
          <el-table-column label="DATA DBTI" align="center" width="90">
            <template slot-scope="scope">
              <span>{{scope.row.properties.CT24_DATA_AGG.substr(0, 10)}}</span>
            </template>
          </el-table-column>
          <el-table-column label="DATA SEL" align="center" width="90">
            <template slot-scope="scope">
              <span>{{scope.row.properties.DATA_SEL.substr(0, 10)}}</span>
            </template>
          </el-table-column>

          <el-table-column label="PARZIALE" align="center" width="80">
            <template slot-scope="scope">
              <span>
                <el-checkbox
                  v-show="editableRow(scope.row.properties.STATO)"
                  v-model="scope.row.properties.parziale"
                />
              </span>
            </template>
          </el-table-column>
          <!-- <el-table-column label="Catalogo" align="center" width="70">
            <template slot-scope="scope">
              <span>
                <el-checkbox v-model="scope.row.properties.catalogo" />
              </span>
            </template>
          </el-table-column>-->
          <el-table-column width="50">
            <template slot-scope="scope">
              <el-button
                v-show="editableRow(scope.row.properties.STATO)"
                size="mini"
                type="danger"
                @click="handleDelete(scope.$index, scope.row)"
                class="fa fa-trash"
              ></el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
    <el-row type="flex" class="row-bg" justify="left">
      <el-button
        id="gv-genio-seleziona-particelle-panel-submit"
        ref="button"
        type="primary"
        @click="submit()"
        size="mini"
        :disabled="buttonDisabled"
      >
        <span>Invia</span>
      </el-button>
      <el-button
        id="gv-draw-cancel"
        title="Ritorno alla applicazione"
        @click="refresh"
        class="gv-color-scheme"
        size="mini"
      >Refresh</el-button>
    </el-row>
  </div>
</template>

<script>
import Vue from "vue";
import getCoordTransform from "../services/getCoordTransform";
import InfoWmsManager from "../controls/InfoWmsManager";
import getFeatureInfo from "../services/getFeatureInfo";
import getWFSFeature from "../services/getWFSFeature";
import insertParticelleGenio from "../services/insertParticelleGenio";

import { Button, Row, Loading, Notification, Popover } from "element-ui";
Vue.use(Button);
Vue.use(Row);
Vue.use(Popover);

export default {
  name: "gv-genio-seleziona-particelle-panel",
  data() {
    return {
      particelleSelezionate: [],
      hiliteLayer: null,
      geojsonLayerList: [],
      options: GV.config.getToolOptions("gv-genio-seleziona-particelle-button")
    };
  },
  computed: {
    buttonDisabled() {
      return false;
      // return this.particelleSelezionate.length === 0;
    }
  },
  methods: {
    refresh() {
      this.loadParticelleInConcessioniAreali();
    },
    editableRow(stato) {
      return stato === "M";
    },
    submit() {
      var r = confirm("Sei sicuro?");
      if (r == true) {
        this.saveData();
      }
      return;
    },
    saveData() {
      const listaParticelle = this.particelleSelezionate.map(particella => {
        particella.properties.id = particella.id;
        return particella.properties;
      });
      var data = {
        prov: this.options.prov,
        codicePratica: this.options.codicePratica,
        listaParticelle: listaParticelle
      };
      const loading = Loading.service({
        text: "Salvataggio dati...",
        background: "rgba(0, 0, 0, 0.8)"
      });
      insertParticelleGenio(data).then(resp => {
        if (loading) loading.close();
        if (resp.success) {
          GV.utils.notification("Dati salvati correttamente", "info");
          // this.loadParticelleInConcessioniAreali();
          this.reloadLayerPratiche();
        } else {
          GV.utils.notification("Errore nella scrittura sul DB", "error");
        }
      });
    },
    reloadLayerPratiche() {
      var layerPratica = GV.globals.GW_CONFIG[this.options.prov].idLayerPratica;
      if (
        this.options.codicePratica.startsWith("GDE") ||
        this.options.codicePratica.startsWith("IMD") ||
        this.options.codicePratica.startsWith("SVD") ||
        this.options.codicePratica.startsWith("SPD")
      ) {
        layerPratica = GV.globals.GW_CONFIG[this.options.prov].idLayerPraticaDe;
      }
      var layerConfig = GV.config.getLayerConfig(layerPratica);
      GV.eventBus.$emit("set-layer-visible", {
        layer: layerConfig,
        checked: false
      });
      GV.eventBus.$emit("set-layer-visible", {
        layer: layerConfig,
        checked: true
      });
    },
    loadLayer() {
      GV.app.map.loadLayers([
        {
          name: "SelezioneParticelle",
          type: "JSON",
          style: {
            color: "#ff0000",
            fillOpacity: 0.0,
            weight: 3,
            opacity: 0.7
          },
          visible: true,
          onEachFeature: (feature, layer) => {
            layer.on("click", ev => {
              // this.hiliteLayer.removeLayer(layer);
            });
          }
        }
      ]);
      this.hiliteLayer = GV.app.map.getLayerByName("SelezioneParticelle");
      this.loadParticelleInConcessioniAreali();
    },
    loadParticelleInConcessioniAreali() {
      this.hiliteLayer.clearLayers();
      this.particelleSelezionate = [];
      const cqlFilter = `CODICE_PRATICA = '${this.options
        .codicePratica}' AND MAPPALE IS NOT NULL`;
      // const cqlFilter = `CODICE_PRATICA = '${this.options
      //   .codicePratica}' AND MAPPALE IS NOT NULL AND G_STATO='M'`;
      const workSpace = `M${this.options.idMap}`;
      const layer = this.options.idLayerPratica;
      const wfsUrl = `http://geoservizi.regione.liguria.it/geoserver/wfs?service=WFS&version=2.0.0&request=GetFeature&srsName=EPSG%3A4326&outputFormat=application%2Fjson&typeName=${workSpace}:${layer}&cql_filter=${cqlFilter}`;
      getWFSFeature(null, null, wfsUrl).then(features => {
        features.forEach(feature => {
          const particella = {
            type: "Feature",
            id: feature.id,
            geometry: feature.geometry,
            bbox: feature.bbox,
            geometry_name: feature.geometry_name,
            properties: {
              CT24_ID: null,
              CT24_COD_COM: feature.properties.COD_COM,
              CT24_SEZ: feature.properties.SEZ,
              CT24_FOGLIO: feature.properties.FOGLIO,
              CT24_NUMERO: feature.properties.MAPPALE,
              CT24_ALLEGATO: feature.properties.ALLEGATO,
              CT24_SVILUPPO: feature.properties.SVILUPPO,
              CT24_PROT_IN: feature.properties.PROT_DBTI,
              CT24_DATA_AGG: feature.properties.DATA_DBTI,
              DATA_SEL: feature.properties.DATA_SEL,
              STATO: feature.properties.G_STATO,
              parziale: feature.properties.MAPPALE_PARZIALE ? true : false
            }
          };
          particella.label = `${particella.properties.CT24_COD_COM}/${particella
            .properties.CT24_SEZ}/${particella.properties
            .CT24_FOGLIO}/${particella.properties.CT24_NUMERO.trim()}/${particella
            .properties.CT24_ALLEGATO}/${particella.properties.CT24_SVILUPPO}`;
          particella.id = particella.label;
          this.particelleSelezionate.push(particella);
          this.hiliteLayer.addData(particella);
        });
      });
    },
    getWmsUrl(event) {
      if (!this.layerConfig) {
        console.error("Configurazione Layer non trovata");
        return;
      }
      let url = GV.globals.DEFAULT_PROXY + this.layerConfig.wmsParams.url;
      const infoFormat = "application/json";
      const infoBuffer = 0;
      const wmsUrl = InfoWmsManager.buildWMSOptions(
        url,
        this.layerConfig.wmsParams.name,
        event.latlng,
        infoFormat,
        infoBuffer
      );
      return wmsUrl;
    },
    updateParticelleSelezionate(features) {
      features.forEach(feature => {
        this.setFeatureProperties(feature);
        if (this.notEditable(feature)) {
          return;
        }
        if (this.alreadySelected(feature)) {
          this.particelleSelezionate = this.particelleSelezionate.filter(
            particella => {
              return particella.id !== feature.id;
            }
          );
          this.hiliteLayer.eachLayer(layer => {
            if (layer.feature.id == feature.id) {
              GV.app.map.removeLayer(layer);
            }
          });
        } else {
          this.particelleSelezionate.push(feature);
          this.updateLayer(feature);
        }
      });
    },
    setFeatureProperties(feature) {
      feature.properties.DATA_SEL = "";
      feature.properties.STATO = "M";
      feature.label = `${feature.properties.CT24_COD_COM}/${feature.properties
        .CT24_SEZ}/${feature.properties
        .CT24_FOGLIO}/${feature.properties.CT24_NUMERO.trim()}/${feature
        .properties.CT24_ALLEGATO}/${feature.properties.CT24_SVILUPPO}`;
      feature.id = feature.label;
      feature.properties.parziale = false;
      feature.properties.catalogo = true;
    },
    updateLayer(feature, type) {
      const cqlFilter = "CT24_ID = " + feature.properties.CT24_ID;
      const wfsUrl =
        "http://geoservizi.regione.liguria.it/geoserver/wfs?service=WFS&version=2.0.0&request=GetFeature&srsName=EPSG%3A4326&outputFormat=application%2Fjson&typeName=M1047:L2624&cql_filter=" +
        cqlFilter;
      getWFSFeature(null, null, wfsUrl).then(features => {
        features.forEach(feature => {
          this.setFeatureProperties(feature);
          this.hiliteLayer.addData(feature);
        });
      });
    },
    notEditable(feature) {
      let notEditable = false;
      this.particelleSelezionate.forEach(particella => {
        if (
          feature.id === particella.id &&
          particella.properties.STATO !== "M"
        ) {
          notEditable = true;
        }
      });
      return notEditable;
    },
    alreadySelected(feature) {
      let selected = false;
      this.particelleSelezionate.forEach(particella => {
        if (feature.id === particella.id) {
          selected = true;
        }
      });
      return selected;
    },
    handleDelete(index, row) {
      this.particelleSelezionate = this.particelleSelezionate.filter(
        particella => {
          return particella.id !== row.id;
        }
      );
      this.hiliteLayer.eachLayer(layer => {
        if (layer.feature.id == row.id) {
          GV.app.map.removeLayer(layer);
        }
      });
    },
    selectRiga(row) {
      if (row) {
        this.hiliteLayer.eachLayer(layer => {
          if (layer.feature.id == row.id) {
            layer.setStyle({ fillOpacity: 0.4 });
          } else {
            layer.setStyle({ fillOpacity: 0.0 });
          }
        });
      }
    },
    deselectRiga(row) {
      if (row) {
        this.hiliteLayer.eachLayer(layer => {
          if (layer.feature.id == row.id) {
            layer.setStyle({ fillOpacity: 0.0 });
          }
        });
      }
    },
    subscribeMapEvent(event) {
      GV.app.map.on("click", event => {
        const wmsUrl = this.getWmsUrl(event);
        getFeatureInfo(wmsUrl).then(features =>
          this.updateParticelleSelezionate(features)
        );
      });
    },
    hideLayer() {
      this.hiliteLayer.eachLayer(layer => {
        layer.getElement().style.display = "none";
      });
    },
    showLayer() {
      this.hiliteLayer.eachLayer(layer => {
        layer.getElement().style.display = "block";
      });
    }
  },
  mounted() {
    this.layerConfig = GV.config.getLayerConfig(this.options.idLayerParticella);
    if (!this.layerConfig) {
      GV.eventBus.$on("gv-config-init", event => {
        this.layerConfig = GV.config.getLayerConfig(
          this.options.idLayerParticella
        );
      });
    }
    this.loadLayer();

    // GESTIONE EVENTI
    GV.eventBus.$on("gv-control-genio-seleziona-particelle-activate", event => {
      this.subscribeMapEvent(event);
      this.showLayer();
    });
    GV.eventBus.$on(
      "gv-control-genio-seleziona-particelle-deactivate",
      event => {
        GV.app.map.off("click");
        this.hideLayer();
      }
    );
    this.subscribeMapEvent(event);
  }
};
</script>

<style>
.gv-genio-seleziona-particelle-panel {
  position: absolute;
  width: 540px;
  left: 0px;
  top: 0px;
  margin-left: 10px;
  margin-top: 50px;
  z-index: 800;
}

.gv-genio-seleziona-particelle-body {
  padding: 5px;
  width: 530px;
  height: 200px;
}

.gv-genio-seleziona-particelle-table {
  padding: 5px;
  overflow-y: auto;
  width: 520px;
  height: 200px;
  max-height: 310px;
}
</style>
