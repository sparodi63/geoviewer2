<template>
  <div class="atlante-geochimico gv-color-scheme">
    <el-select
      placeholder="Seleziona Livello"
      v-model="livello"
      size="mini"
      filterable
      @change="onChange"
    >
      <el-option v-for="item in livelli" :key="item.id" :value="item.id" :label="item.title"></el-option>
    </el-select>
  </div>
</template>


<script>
import Vue from "vue";
import { Select, Option } from "element-ui";
Vue.use(Select);
Vue.use(Option);
import mountComponent from "../util/mountComponent";
import getConfig from "../services/getAtlanteGeochimicoConfig";

Vue.component("gv-multi-legend-panel", () => import("./MultiLegendPanel.vue"));

export default {
  data() {
    return {
      livelli: [],
      livello: null,
      downloadConfig: null,
      metaData: null
    };
  },
  methods: {
    onChange(value) {
      const layersConfig = this.livelli.filter(livello => {
        return livello.id == value;
      });
      this.loadLayer(layersConfig[0]);
      this.showLegend(layersConfig[0]);
      this.cleanUpDownload();
    },
    cleanUpDownload() {
      const dlPanel = document.getElementById("gv-map-download");
      if (dlPanel) {
        dlPanel.parentNode.removeChild(dlPanel);
      }
      const layerMacrobacini = GV.app.map.getLayerByName(
        "SelezioneMacrobacino"
      );
      if (layerMacrobacini) {
        GV.app.map.removeLayer(layerMacrobacini);
      }
      // Riattivo controllo
      GV.config.activeControl.activate();
    },
    loadLayer(layerConfig) {
      layerConfig.visible = true;
      const idMap = layerConfig.idMap;
      GV.config.removeMap(idMap);
      GV.config.addMapConfig({
        id: idMap,
        name: "Atlante Geochimico",
        flagGeoserver: true,
        downloadConfig: this.downloadConfig,
        metaData: this.metaData,
        layers: [layerConfig]
      });
    },
    showLegend(layerConfig) {
      mountComponent({
        elId: "gv-multi-legend-panel",
        containerId: GV.config.containerId,
        clear: true,
        vm: new Vue({
          template: `<gv-multi-legend-panel 
            visible="true" 
            src="${layerConfig.wmsParams
              .url}LAYER=${layerConfig.name}&REQUEST=GetLegendGraphic&VERSION=1.0.0&FORMAT=image/png&WIDTH=20&HEIGHT=20&" 
            height="120" 
            width="250" 
            :title="false"  
            noClose="true">
            </gv-multi-legend-panel>`
        })
      });
    }
  },
  mounted: function() {
    getConfig().then(data => {
      this.livelli = data.layers;
      this.downloadConfig = data.downloadConfig;
      this.metaData = data.metaData;
    });
  }
};
</script>

<style scoped>
.atlante-geochimico {
  width: 250px;
  z-index: 800;
  padding: 10px;
}
.label {
  display: inline-block;
  width: 120px;
}
</style>