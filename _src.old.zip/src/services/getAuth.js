import axios from 'axios'
import globals from '../globals'

export default function getAuth(ruolo, test) {
  let url = '/geoservices/REST/utils/autorizza_nam/GEOVIEWER/' + ruolo
  const params = {
    test: test
  }
  return axios.get(url, {
    params: params
  }).then(response => response.data)
}
