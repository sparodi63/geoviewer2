import axios from 'axios'
import globals from '../globals'

// export default function() {
//   return axios.get(`/geoservices/REST/atlante_geochimico/livelli/`).then(response => response.data.data)
// }

export default function() {
  const idMap = 1881
  let url = `${globals.RL_DYN_MAP_CONFIG_SERVICE}${idMap}`

  return axios.get(url).then(response => response.data.data)
}
